import "./styles.css";
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';
import LoginPage from "./components/LoginPage"
import EmployeeDashboard from "./components/EmployeeDashboard";
export default function App() {
  return (
    <Router>
    <div className="App">
      <Switch>
       <Route path='/login'> 
      <LoginPage/>
      </Route>
      <Route path='/dashboard'> 
      <EmployeeDashboard/>
      </Route>
      </Switch>
    </div>
    </Router>
  );
}
