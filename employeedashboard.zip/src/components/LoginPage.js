import React, { useEffect, useState } from 'react'
import { useHistory } from "react-router-dom";
import { FormControl,Input,FormHelperText } from '@material-ui/core'
const LoginPage=()=>{
    const [ userDetails,setUserDetails ] = useState({useName:'',password:''})
    const [ registeredDetails,setRegisteredDetails] = useState({})
    const [ statusMessage,setStausMessage] = useState('')
    const [ userError, setUserError ] = useState()
    const [ passwordError, setPasswordError ] = useState()
    let history = useHistory()
    const onTextChanged=(e)=>{
        const { name,value }=e.target
        setUserDetails(userDetails=>({
            ...userDetails,
            [name]:value
        }))
    }
    const isvalidUserName = (inputValue) => {
      const userNamePattern = new RegExp('^[a-zA-Z0-9_]')
      return userNamePattern.test(inputValue) ? true : false
  }
    const handleUserName=(event)=>{
      const value = event.target.value
        if (!isvalidUserName(value)) {
            setUserError('Please enter valid username')
        }
        else {
            setUserError()
        }
      }
      const isvalidPassword = (inputValue) => {
        const passwordPattern = new RegExp('[a-zA-Z0-9_@]')
        return passwordPattern.test(inputValue) ? true : false
    }
      const handlePassword=(event)=>{
        const value = event.target.value
          if (!isvalidPassword(value)) {
              setPasswordError('Please enter valid password')
          }
          else {
              setPasswordError()
          }
        }
    useEffect(()=>{
          loadData()
    },[])
    const loadData =()=>{
          fetch('http://localhost:8000/login').then(response=>response.json()).then(result => {
          setRegisteredDetails(result)
        })
    }
    const onSubmitDetails=(e)=>{
      e.preventDefault()
    if( userDetails.userName === registeredDetails.username && userDetails.password === registeredDetails.password){
    history.push("/dashboard");
    }
    else{
        setStausMessage('Please Enter Correct UserName and Password')
    }
}
    return (
        <div className="App-header">
        <div>   
        <FormControl fullWidth> 
            <Input
                id = "userName"
                value={ userDetails.userName }
                name="userName"
                placeholder="User Name"
                onChange={ onTextChanged }
                onInput={ handleUserName }
                required = { true }
            />
            <FormHelperText style={ { color:'red' } }>{userError}</FormHelperText>
        </FormControl>
     
        </div>  
        <div>   
        <FormControl fullWidth>
            <Input
                type="password"
                id = "password"
                value={ userDetails.password }
                name="password"
                placeholder="Password"
                onChange={ onTextChanged }
                onInput={ handlePassword }
                required = { true }
            />
             <FormHelperText style={ { color:'red' } }>{passwordError}</FormHelperText>
        </FormControl>
        </div> 
        <div>
            <input type="submit" onClick={ onSubmitDetails }/>
            <input type="reset"/>
        </div>
        <div>
          { statusMessage }
        </div>
        </div>  
    )
}
export default LoginPage
