import React, { useEffect, useState } from 'react'
import MaterialTable from 'material-table'
const EmployeeDashboard=()=>{
    const [ employeeDetails,setEmployeeDetails ] = useState([])

    useEffect(()=>{
          loadData()
    })
    const loadData =()=>{
          fetch('http://localhost:8000/user').then(response=>response.json()).then(result => {
          setEmployeeDetails(result)
        })
    }
    let columns = [
      { title: 'Name', sorting: true, field: 'name' },
      { title: 'Age', sorting: true, field: 'age' },
      { title: 'Gender', field: 'gender' },
      { title: 'Phone', field:'phoneNo'},
      { title: 'Email', field:'email'}
    ]
    return (
      <div>
       { employeeDetails &&   <MaterialTable
            columns={columns}
            data={employeeDetails}
            title='Employee Dashboard'
            options={{
                padding: "dense",
            }}
        /> }
        </div>
    )
}
export default EmployeeDashboard
